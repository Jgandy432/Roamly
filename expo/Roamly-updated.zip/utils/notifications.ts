import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

// Configure how notifications appear when the app is in the foreground
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});

export async function requestNotificationPermissions(): Promise<boolean> {
  if (Platform.OS === 'web') return false;
  const { status: existing } = await Notifications.getPermissionsAsync();
  if (existing === 'granted') return true;
  const { status } = await Notifications.requestPermissionsAsync();
  return status === 'granted';
}

export async function sendLocalNotification(title: string, body: string) {
  try {
    await Notifications.scheduleNotificationAsync({
      content: { title, body },
      trigger: null, // fires immediately
    });
  } catch (e) {
    console.log('Notification failed:', e);
  }
}

// Ready-made notification triggers for key app events
export const TripNotifications = {
  preferencesSubmitted: (memberName: string, tripName: string) =>
    sendLocalNotification(
      '✅ Preferences submitted!',
      `${memberName} submitted their preferences for ${tripName}.`
    ),

  planGenerated: (tripName: string, destination: string) =>
    sendLocalNotification(
      '🎉 Trip plan ready!',
      `Your plan for ${tripName} to ${destination} is ready. Open the app to check it out!`
    ),

  planFinalized: (tripName: string) =>
    sendLocalNotification(
      '✈️ Trip finalized!',
      `${tripName} has been finalized. Time to start packing!`
    ),

  memberJoined: (memberName: string, tripName: string) =>
    sendLocalNotification(
      '👋 New member!',
      `${memberName} just joined ${tripName}.`
    ),
};
