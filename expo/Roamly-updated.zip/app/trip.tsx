import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Animated,
  Alert,
  Platform,
  Share,
  TextInput,
  Modal,
} from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ChevronLeft, Copy, Check, Sparkles, UserPlus, Trash2, Pencil } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useTrips } from '@/context/TripContext';
import { Colors } from '@/constants/colors';
import PlanView from '@/components/PlanView';
import BottomTabBar from '@/components/BottomTabBar';

export default function TripScreen() {
  const router = useRouter();
  const {
    activeTrip,
    activeTripPlan,
    currentUser,
    isGenerating,
    genProgress,
    addDemoMembers,
    generatePlan,
    castVote,
    finalizePlan,
    deleteTrip,
    updateTrip,
    setActiveTrip,
    setActiveTripPlan,
  } = useTrips();
  const [copied, setCopied] = useState<boolean>(false);
  const [genError, setGenError] = useState<string | null>(null);
  const [showEditModal, setShowEditModal] = useState<boolean>(false);
  const [editName, setEditName] = useState<string>('');
  const [editDest, setEditDest] = useState<string>('');
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (isGenerating) {
      const pulse = Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.05, duration: 1000, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
        ])
      );
      pulse.start();
      return () => pulse.stop();
    }
  }, [isGenerating]);

  if (!activeTrip || !currentUser) {
    return (
      <View style={styles.root}>
        <SafeAreaView style={styles.center}>
          <Text style={styles.errorText}>No trip selected</Text>
          <TouchableOpacity onPress={() => router.replace('/dashboard')}>
            <Text style={styles.linkText}>Go to Dashboard</Text>
          </TouchableOpacity>
        </SafeAreaView>
      </View>
    );
  }

  const isLeader = activeTrip.leaderId === currentUser.id;
  const myMembership = activeTrip.members.find((m) => m.id === currentUser.id);
  const submittedCount = activeTrip.members.filter((m) => m.preferencesSubmitted).length;
  const progressPct = activeTrip.members.length > 0 ? (submittedCount / activeTrip.members.length) * 100 : 0;

  const copyInvite = async () => {
    try {
      if (Platform.OS === 'web') {
        await navigator.clipboard?.writeText(`roamly.app/join/${activeTrip.inviteCode}`);
      }
      setCopied(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      console.log('Copy failed');
    }
  };

  const handleGenerate = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setGenError(null);
    const result = await generatePlan();
    if (result.success) {
      Alert.alert('Success', result.message);
    } else {
      setGenError(result.message);
    }
  };

  const handleAddDemo = () => {
    addDemoMembers();
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Alert.alert('Done', '4 demo members added with preferences!');
  };

  const handleShareTrip = async () => {
    if (!activeTrip) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    const inviteUrl = `https://roamly.app/join/${activeTrip.inviteCode}`;
    const memberCount = activeTrip.members.length;
    const dateInfo = activeTripPlan?.summary?.recommended_dates
      ? ` | ${activeTripPlan.summary.recommended_dates}`
      : '';
    const message = `Join our trip to ${activeTrip.destination}!\n\n🗺 ${activeTrip.name}\n📍 ${activeTrip.destination}${dateInfo}\n👥 ${memberCount} ${memberCount === 1 ? 'person' : 'people'} already joined\n\n${inviteUrl}`;

    try {
      await Share.share(
        {
          message,
          url: inviteUrl,
          title: `Join ${activeTrip.name} on Roamly`,
        },
        {
          subject: `You're invited to ${activeTrip.name}!`,
          dialogTitle: 'Share Trip Invite',
        }
      );
    } catch (err) {
      console.log('Share failed:', err);
    }
  };

  const handleDeleteTrip = () => {
    Alert.alert(
      'Delete Trip',
      `Are you sure you want to delete "${activeTrip.name}"? This can't be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            deleteTrip(activeTrip.id);
            router.replace('/dashboard');
          },
        },
      ]
    );
  };

  const handleEditTrip = () => {
    setEditName(activeTrip.name);
    setEditDest(activeTrip.destination);
    setShowEditModal(true);
  };

  const handleSaveEdit = () => {
    if (!editName.trim()) return;
    updateTrip(activeTrip.id, { name: editName.trim(), destination: editDest.trim() });
    setShowEditModal(false);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const handleBack = () => {
    setActiveTrip(null);
    setActiveTripPlan(null);
    router.back();
  };

  return (
    <View style={styles.root}>
      <SafeAreaView style={styles.flex}>
        <Animated.View style={[styles.flex, { opacity: fadeAnim }]}>
          <TouchableOpacity style={styles.backBtn} onPress={handleBack}>
            <ChevronLeft size={20} color={Colors.textMuted} />
            <Text style={styles.backText}>Dashboard</Text>
          </TouchableOpacity>

          <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
            <View style={styles.tripHeader}>
              <View style={styles.tripHeaderLeft}>
                <Text style={styles.tripName}>{activeTrip.name}</Text>
                <Text style={styles.tripMeta}>
                  {activeTrip.destination}
                </Text>
              </View>
              <View style={styles.tripHeaderRight}>
                {isLeader && activeTrip.status === 'collecting' && (
                  <View style={styles.tripActions}>
                    <TouchableOpacity style={styles.tripActionBtn} onPress={handleEditTrip}>
                      <Pencil size={14} color={Colors.textSecondary} />
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.tripActionBtn} onPress={handleDeleteTrip}>
                      <Trash2 size={14} color="#E5484D" />
                    </TouchableOpacity>
                  </View>
                )}
                <View style={[
                  styles.statusBadge,
                  { backgroundColor: activeTrip.status === 'finalized' ? Colors.emeraldMuted : activeTrip.status === 'planned' ? Colors.emeraldMuted : Colors.amberMuted }
                ]}>
                  <Text style={[
                    styles.statusText,
                    { color: activeTrip.status === 'finalized' ? Colors.emerald : activeTrip.status === 'planned' ? Colors.emerald : '#D4950A' }
                  ]}>
                    {activeTrip.status === 'finalized' ? 'Finalized' : activeTrip.status === 'planned' ? 'Plan Ready' : 'Collecting'}
                  </Text>
                </View>
              </View>
            </View>

            <Modal visible={showEditModal} transparent animationType="fade">
              <View style={styles.modalOverlay}>
                <View style={styles.modalCard}>
                  <Text style={styles.modalTitle}>Edit Trip</Text>
                  <Text style={styles.modalLabel}>Trip Name</Text>
                  <TextInput
                    style={styles.modalInput}
                    value={editName}
                    onChangeText={setEditName}
                    placeholder="Trip name"
                    placeholderTextColor={Colors.textDark}
                  />
                  <Text style={styles.modalLabel}>Destination</Text>
                  <TextInput
                    style={styles.modalInput}
                    value={editDest}
                    onChangeText={setEditDest}
                    placeholder="Destination"
                    placeholderTextColor={Colors.textDark}
                  />
                  <View style={styles.modalBtns}>
                    <TouchableOpacity style={styles.modalCancelBtn} onPress={() => setShowEditModal(false)}>
                      <Text style={styles.modalCancelText}>Cancel</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.modalSaveBtn} onPress={handleSaveEdit}>
                      <Text style={styles.modalSaveText}>Save</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            </Modal>

            {activeTrip.status === 'collecting' && (
              <View style={styles.inviteCard}>
                <View style={styles.inviteTop}>
                  <View style={styles.inviteLeft}>
                    <Text style={styles.inviteLabel}>Share invite link</Text>
                    <View style={styles.inviteLinkRow}>
                      <View style={styles.inviteLinkBg}>
                        <Text style={styles.inviteLink}>roamly.app/join/{activeTrip.inviteCode}</Text>
                      </View>
                      <TouchableOpacity style={styles.copyBtn} onPress={copyInvite}>
                        {copied ? (
                          <Check size={14} color={Colors.emerald} />
                        ) : (
                          <Copy size={14} color={Colors.textSecondary} />
                        )}
                      </TouchableOpacity>
                    </View>
                  </View>
                  <View style={styles.inviteRight}>
                    <Text style={styles.inviteCodeLabel}>Invite Code</Text>
                    <Text style={styles.inviteCode}>{activeTrip.inviteCode}</Text>
                  </View>
                </View>
              </View>
            )}

            <View style={styles.membersCard}>
              <View style={styles.membersHeader}>
                <Text style={styles.membersTitle}>Group Members</Text>
                <Text style={styles.membersCount}>{submittedCount}/{activeTrip.members.length} submitted</Text>
              </View>

              <View style={styles.progressBar}>
                <View style={[styles.progressFill, { width: `${progressPct}%` }]} />
              </View>

              {activeTrip.members.map((m) => (
                <View key={m.id} style={styles.memberRow}>
                  <View style={styles.memberAvatar}>
                    <Text style={styles.memberAvatarText}>{m.avatar || m.name.charAt(0)}</Text>
                  </View>
                  <View style={styles.memberInfo}>
                    <Text style={styles.memberName}>{m.name}</Text>
                    {m.role === 'leader' && <Text style={styles.leaderBadge}>Leader</Text>}
                  </View>
                  <View style={[
                    styles.submittedBadge,
                    { backgroundColor: m.preferencesSubmitted ? Colors.emeraldMuted : Colors.bgCard }
                  ]}>
                    <Text style={[
                      styles.submittedText,
                      { color: m.preferencesSubmitted ? Colors.emerald : Colors.textMuted }
                    ]}>
                      {m.preferencesSubmitted ? '✓ Submitted' : 'Waiting'}
                    </Text>
                  </View>
                </View>
              ))}

              <View style={styles.actionsDivider} />
              <View style={styles.actionsRow}>
                {!myMembership?.preferencesSubmitted && (
                  <TouchableOpacity
                    style={styles.primaryBtn}
                    onPress={() => router.push('/preferences')}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.primaryBtnText}>Enter My Preferences</Text>
                  </TouchableOpacity>
                )}
                {myMembership?.preferencesSubmitted && !activeTripPlan && (
                  <TouchableOpacity
                    style={styles.secondaryBtn}
                    onPress={() => router.push('/preferences')}
                  >
                    <Text style={styles.secondaryBtnText}>Edit Preferences</Text>
                  </TouchableOpacity>
                )}
                {isLeader && activeTrip.members.length < 3 && (
                  <TouchableOpacity style={styles.secondaryBtn} onPress={handleAddDemo}>
                    <UserPlus size={14} color={Colors.textSecondary} />
                    <Text style={styles.secondaryBtnText}>Add Demo Members</Text>
                  </TouchableOpacity>
                )}
                {isLeader && !activeTripPlan && !isGenerating && (
                  <TouchableOpacity
                    style={[styles.generateBtn, submittedCount < 2 && styles.generateBtnDisabled]}
                    onPress={handleGenerate}
                    disabled={submittedCount < 2}
                    activeOpacity={0.8}
                  >
                    <Sparkles size={14} color="#FFFFFF" />
                    <Text style={styles.generateBtnText}>Generate Trip Plan</Text>
                  </TouchableOpacity>
                )}
              </View>
            </View>

            {isGenerating && (
              <Animated.View style={[styles.generatingCard, { transform: [{ scale: pulseAnim }] }]}>
                <View style={styles.spinnerWrap}>
                  <Animated.View style={styles.spinner} />
                </View>
                <Text style={styles.genProgressText}>{genProgress}</Text>
                <Text style={styles.genSubText}>This takes about 15-20 seconds</Text>
              </Animated.View>
            )}

            {activeTripPlan && !isGenerating && genError && (
              <View style={styles.errorCard}>
                <Text style={styles.errorIcon}>⚠️</Text>
                <Text style={styles.errorTitle}>AI generation hit a snag</Text>
                <Text style={styles.errorDesc}>
                  We loaded a sample plan so you can still explore the app. Hit retry to try the AI again.
                </Text>
                <TouchableOpacity style={styles.retryBtn} onPress={handleGenerate} activeOpacity={0.8}>
                  <Text style={styles.retryBtnText}>Retry AI Generation</Text>
                </TouchableOpacity>
              </View>
            )}

            {activeTripPlan && !isGenerating && (
              <PlanView
                plan={activeTripPlan}
                votes={activeTrip.votes || []}
                currentUserId={currentUser.id}
                isLeader={isLeader}
                onVote={castVote}
                finalized={activeTrip.finalized}
                onFinalize={finalizePlan}
                onShareTrip={handleShareTrip}
                shareTripInfo={{
                  tripName: activeTrip.name,
                  destination: activeTrip.destination,
                  dates: activeTripPlan.summary.recommended_dates,
                  memberCount: activeTrip.members.length,
                  inviteCode: activeTrip.inviteCode,
                }}
              />
            )}
          </ScrollView>
        </Animated.View>
      </SafeAreaView>
      <BottomTabBar />
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.bg },
  flex: { flex: 1 },
  center: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  errorText: { fontSize: 16, color: Colors.textMuted, marginBottom: 12 },
  linkText: { fontSize: 14, color: Colors.orange },
  backBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 24,
    paddingVertical: 12,
  },
  backText: { fontSize: 14, color: Colors.textMuted },
  scrollContent: { paddingHorizontal: 24, paddingBottom: 40 },
  tripHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 20,
  },
  tripHeaderLeft: { flex: 1, marginRight: 12 },
  tripHeaderRight: { alignItems: 'flex-end', gap: 8 },
  tripActions: { flexDirection: 'row', gap: 6 },
  tripActionBtn: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: Colors.bgCard,
    borderWidth: 1,
    borderColor: Colors.border,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tripName: { fontSize: 26, fontWeight: '700' as const, color: Colors.text },
  tripMeta: { fontSize: 13, color: Colors.textMuted, marginTop: 4 },
  statusBadge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10 },
  statusText: { fontSize: 11, fontWeight: '600' as const },
  inviteCard: {
    backgroundColor: Colors.bgCard,
    borderWidth: 1,
    borderColor: Colors.borderLight,
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
  },
  inviteTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  inviteLeft: { flex: 1, marginRight: 16 },
  inviteLabel: { fontSize: 11, color: Colors.textMuted, marginBottom: 6 },
  inviteLinkRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  inviteLinkBg: {
    backgroundColor: Colors.bgInput,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 8,
    flex: 1,
  },
  inviteLink: { fontSize: 12, color: Colors.orange, fontWeight: '500' as const },
  copyBtn: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: Colors.bgInput,
    borderWidth: 1,
    borderColor: Colors.border,
    justifyContent: 'center',
    alignItems: 'center',
  },
  inviteRight: { alignItems: 'flex-end' },
  inviteCodeLabel: { fontSize: 11, color: Colors.textMuted, marginBottom: 2 },
  inviteCode: {
    fontSize: 20,
    fontWeight: '700' as const,
    color: Colors.orange,
    letterSpacing: 3,
  },
  membersCard: {
    backgroundColor: Colors.bgCard,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
  },
  membersHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  membersTitle: { fontSize: 14, fontWeight: '600' as const, color: Colors.text },
  membersCount: { fontSize: 12, color: Colors.textMuted },
  progressBar: {
    height: 4,
    backgroundColor: Colors.border,
    borderRadius: 2,
    marginBottom: 14,
    overflow: 'hidden',
  },
  progressFill: {
    height: 4,
    backgroundColor: Colors.orange,
    borderRadius: 2,
  },
  memberRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 7,
  },
  memberAvatar: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: Colors.orangeMuted,
    justifyContent: 'center',
    alignItems: 'center',
  },
  memberAvatarText: { fontSize: 12, fontWeight: '600' as const, color: Colors.orange },
  memberInfo: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6 },
  memberName: { fontSize: 14, color: Colors.text },
  leaderBadge: { fontSize: 11, color: Colors.orange },
  submittedBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  submittedText: { fontSize: 11, fontWeight: '500' as const },
  actionsDivider: {
    height: 1,
    backgroundColor: Colors.border,
    marginTop: 14,
    marginBottom: 14,
  },
  actionsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  primaryBtn: {
    backgroundColor: Colors.orange,
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 9,
  },
  primaryBtnText: { fontSize: 12, fontWeight: '700' as const, color: '#FFFFFF' },
  secondaryBtn: {
    backgroundColor: Colors.bgInput,
    borderWidth: 1,
    borderColor: Colors.border,
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 9,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  secondaryBtnText: { fontSize: 12, fontWeight: '600' as const, color: Colors.textSecondary },
  generateBtn: {
    backgroundColor: Colors.orange,
    paddingHorizontal: 16,
    paddingVertical: 9,
    borderRadius: 9,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    shadowColor: Colors.orange,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 4,
  },
  generateBtnDisabled: { opacity: 0.3 },
  generateBtnText: { fontSize: 12, fontWeight: '700' as const, color: '#FFFFFF' },
  generatingCard: {
    backgroundColor: Colors.bgCard,
    borderWidth: 1,
    borderColor: Colors.borderOrange,
    borderRadius: 16,
    padding: 28,
    alignItems: 'center',
    marginBottom: 16,
  },
  spinnerWrap: { marginBottom: 14 },
  spinner: {
    width: 36,
    height: 36,
    borderRadius: 18,
    borderWidth: 2,
    borderColor: Colors.orangeMuted,
    borderTopColor: Colors.orange,
  },
  genProgressText: { fontSize: 14, fontWeight: '500' as const, color: Colors.text },
  genSubText: { fontSize: 12, color: Colors.textDim, marginTop: 6 },
  errorCard: {
    backgroundColor: '#FFF8F0',
    borderWidth: 1,
    borderColor: '#FFD6A5',
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    marginBottom: 16,
  },
  errorIcon: { fontSize: 28, marginBottom: 8 },
  errorTitle: { fontSize: 15, fontWeight: '600' as const, color: Colors.text, marginBottom: 6 },
  errorDesc: { fontSize: 13, color: Colors.textSecondary, textAlign: 'center' as const, lineHeight: 20, marginBottom: 14 },
  retryBtn: {
    backgroundColor: Colors.orange,
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 10,
  },
  retryBtnText: { fontSize: 13, fontWeight: '700' as const, color: '#FFFFFF' },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 28,
  },
  modalCard: {
    backgroundColor: Colors.bg,
    borderRadius: 20,
    padding: 24,
    width: '100%',
    maxWidth: 400,
  },
  modalTitle: { fontSize: 18, fontWeight: '700' as const, color: Colors.text, marginBottom: 20 },
  modalLabel: { fontSize: 12, fontWeight: '600' as const, color: Colors.textSecondary, marginBottom: 6 },
  modalInput: {
    backgroundColor: Colors.bgInput,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: Colors.text,
    marginBottom: 14,
  },
  modalBtns: { flexDirection: 'row', gap: 10, marginTop: 6 },
  modalCancelBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    backgroundColor: Colors.bgCard,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: 'center',
  },
  modalCancelText: { fontSize: 14, fontWeight: '600' as const, color: Colors.textSecondary },
  modalSaveBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 10,
    backgroundColor: Colors.orange,
    alignItems: 'center',
  },
  modalSaveText: { fontSize: 14, fontWeight: '700' as const, color: '#FFFFFF' },
});
